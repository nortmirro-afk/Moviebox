package com.example.movieboxmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

private val Ink = Color(0xFF101117)
private val Panel = Color(0xFF1B1D27)
private val Accent = Color(0xFFB8F34A)
private val Muted = Color(0xFF9EA1B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MovieBoxApp() }
    }
}

data class Film(val title: String, val year: String, val genre: String, val poster: String, val description: String)

private val films = listOf(
    Film("Dune: Part Two", "2024", "Sci-Fi", "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg", "Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family."),
    Film("The Batman", "2022", "Crime", "https://image.tmdb.org/t/p/w500/74xTEgt7R36Fpooo50r9T25onhq.jpg", "Batman investigates corruption in Gotham while pursuing a mysterious serial killer."),
    Film("Spider-Man: Across the Spider-Verse", "2023", "Animation", "https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5XjfewQv.jpg", "Miles Morales journeys across the multiverse and meets a team of Spider-People."),
    Film("Interstellar", "2014", "Adventure", "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg", "A team of explorers travels beyond this galaxy to discover whether mankind has a future among the stars."),
    Film("Oppenheimer", "2023", "Drama", "https://image.tmdb.org/t/p/w500/ptpr0kGAckfQkJeJIt8st5dglvd.jpg", "The story of J. Robert Oppenheimer and the development of the atomic bomb."),
    Film("Everything Everywhere All at Once", "2022", "Fantasy", "https://image.tmdb.org/t/p/w500/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg", "An exhausted laundromat owner becomes the unlikely hero of the multiverse."),
)

@Composable
fun MovieBoxApp() {
    var tab by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Film?>(null) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    val filtered = films.filter { it.title.contains(query, true) || it.genre.contains(query, true) }

    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Accent, onPrimary = Ink, onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            if (selected != null) {
                FilmDetails(film = selected!!, isFavorite = favorites.contains(selected!!.title), onBack = { selected = null }, onFavorite = {
                    favorites = if (favorites.contains(selected!!.title)) favorites - selected!!.title else favorites + selected!!.title
                }, onPlay = { /* Playback is connected after the MovieBox-TUI provider bridge is implemented. */ })
            } else {
                Scaffold(containerColor = Ink, bottomBar = {
                    NavigationBar(containerColor = Panel, contentColor = Color.White) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = navColors())
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") }, colors = navColors())
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.FavoriteBorder, null) }, label = { Text("Saved") }, colors = navColors())
                    }
                }) { padding ->
                    LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(bottom = 22.dp)) {
                        item { Header() }
                        if (tab == 1) item {
                            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp), placeholder = { Text("Search movies or genres", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                        }
                        if (tab == 0) {
                            item { HeroCard(film = films.first(), onClick = { selected = films.first() }) }
                            item { SectionTitle("Popular this week", "Trending") }
                            item { PosterRow(films, onSelect = { selected = it }) }
                            item { SectionTitle("Explore by mood", "Categories") }
                            item { CategoryRow() }
                            item { SectionTitle("Worth your time", "Picked for you") }
                            items(films.drop(1).take(4)) { film -> WideFilmRow(film, onClick = { selected = film }) }
                        } else if (tab == 2) {
                            item { SectionTitle("Your saved titles", "Library") }
                            val saved = films.filter { favorites.contains(it.title) }
                            if (saved.isEmpty()) item { EmptyState("Your list is empty", "Tap the heart on a title to save it here.") }
                            items(saved) { film -> WideFilmRow(film, onClick = { selected = film }) }
                        } else {
                            item { SectionTitle("Find your next favourite", "Search") }
                            items(filtered) { film -> WideFilmRow(film, onClick = { selected = film }) }
                            if (filtered.isEmpty()) item { EmptyState("No titles found", "Try another title or genre.") }
                        }
                        item { Text("Demo interface • MovieBox-TUI integration not connected yet", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(20.dp)) }
                    }
                }
            }
        }
    }
}

@Composable private fun navColors() = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF343B27), unselectedIconColor = Muted, unselectedTextColor = Muted)

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Accent), contentAlignment = Alignment.Center) { Icon(Icons.Default.VideoLibrary, null, tint = Ink, modifier = Modifier.size(25.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text("MOVIEBOX", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("YOUR CINEMA, YOUR WAY", fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp) }
        Box(Modifier.size(38.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) { Text("M", color = Accent, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun HeroCard(film: Film, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(410.dp).clip(RoundedCornerShape(26.dp)).clickable { onClick() }) {
        AsyncImage(model = film.poster, contentDescription = film.title, modifier = Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xAA101117), Ink))))
        Column(Modifier.align(Alignment.BottomStart).padding(22.dp)) {
            Text("FEATURED FILM", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp)); Text(film.title, fontSize = 31.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("${film.year}  •  ${film.genre}  •  Featured", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Spacer(Modifier.height(15.dp))
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink), shape = RoundedCornerShape(12.dp)) { Text("Explore title", fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable private fun SectionTitle(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 25.dp, bottom = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(subtitle.uppercase(), fontSize = 9.sp, color = Muted, letterSpacing = 1.5.sp) }
        Text("VIEW ALL  ›", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun PosterRow(list: List<Film>, onSelect: (Film) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        list.forEach { film -> Column(Modifier.width(142.dp).clickable { onSelect(film) }) {
            AsyncImage(model = film.poster, contentDescription = film.title, modifier = Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(15.dp)))
            Spacer(Modifier.height(8.dp)); Text(film.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${film.year}  •  ${film.genre}", color = Muted, fontSize = 11.sp)
        } }
    }
}

@Composable private fun CategoryRow() {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        listOf("Action", "Sci-Fi", "Drama", "Anime", "Thriller", "Comedy").forEachIndexed { i, category ->
            Box(Modifier.clip(RoundedCornerShape(30.dp)).background(if (i == 1) Accent else Panel).clickable { }.padding(horizontal = 16.dp, vertical = 11.dp)) { Text(category, color = if (i == 1) Ink else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable private fun WideFilmRow(film: Film, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = film.poster, contentDescription = film.title, modifier = Modifier.width(78.dp).height(108.dp).clip(RoundedCornerShape(12.dp)))
        Column(Modifier.weight(1f).padding(start = 14.dp, end = 8.dp)) {
            Text(film.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("${film.year}  •  ${film.genre}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(film.description, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
        }
        Text("›", color = Accent, fontSize = 28.sp)
    }
}

@Composable private fun FilmDetails(film: Film, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit, onPlay: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Box(Modifier.fillMaxWidth().height(460.dp)) {
                AsyncImage(model = film.poster, contentDescription = film.title, modifier = Modifier.fillMaxSize())
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x33000000), Ink))))
                Text("‹  Back", modifier = Modifier.align(Alignment.TopStart).padding(20.dp).clip(RoundedCornerShape(20.dp)).background(Panel.copy(alpha = .85f)).clickable { onBack() }.padding(horizontal = 14.dp, vertical = 9.dp), color = Color.White)
            }
            Column(Modifier.padding(horizontal = 22.dp)) {
                Text(film.title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("${film.year}  •  ${film.genre}", color = Muted, modifier = Modifier.padding(top = 6.dp))
                Text(film.description, color = Color.LightGray, lineHeight = 23.sp, modifier = Modifier.padding(top = 18.dp))
                Row(Modifier.fillMaxWidth().padding(top = 22.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onPlay, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Ink), shape = RoundedCornerShape(14.dp)) { Text("▶  Find stream") }
                    OutlinedButton(onClick = onFavorite, colors = ButtonDefaults.outlinedButtonColors(contentColor = Accent), shape = RoundedCornerShape(14.dp)) { Text(if (isFavorite) "♥ Saved" else "♡ Save") }
                }
                Text("Stream search will be enabled when the MovieBox-TUI engine is connected.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 18.dp, bottom = 28.dp))
            }
        }
    }
}

@Composable private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, modifier = Modifier.padding(top = 8.dp)) }
}
