package com.example.movieboxmobile.core

/**
 * Integration seam for the upstream MovieBox-TUI Rust engine.
 * This starter deliberately does not pretend the terminal UI is a mobile API.
 * The next phase must either expose a stable JSON/IPC interface from the Rust
 * engine or port the provider/search/playback calls into a native bridge.
 */
interface MovieBoxEngine {
    suspend fun search(query: String): List<MovieResult>
    suspend fun getStreams(resultId: String): List<StreamResult>
}

data class MovieResult(val id: String, val title: String, val year: String?, val posterUrl: String?)
data class StreamResult(val url: String, val quality: String?, val headers: Map<String, String> = emptyMap())
